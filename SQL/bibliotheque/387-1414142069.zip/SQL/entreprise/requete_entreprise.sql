-- Dans la console, clic sur l'icone en haut � gauche > propri�t� > configuration > Taille de la fenetre pour augmenter en largeur !
-- Les requ�tes ne pas senssible � la casse, mais une convention indique qu'il faut mettre les mots-cl�s des requetes en majuscule.
-- La fleche du haut (au clavier) est un racourrci pour l'historique des requ�tes.
-- Parler du copier/coller dans la console (clic droit -> selectionn� -> entrer).
-- Pour l'intervenant, sur son pc portable, il est pr�f�rable de taper les requ�tes dans l'onglet "SQL" de PMA car si une requete est mauvaise ca ne sonne pas comme sur la console windows xp !

CREATE DATABASE tic_entreprise; -- Cr�er une nouvelle base de donn�es

SHOW DATABASES; -- permet de voir les bases de donn�es

USE tic_entreprise; -- Utiliser une base de donn�es

DROP DATABASE tic_entreprise ; -- Supprimer une base de donn�es

DROP table employes ; -- Supprimer une table

TRUNCATE nom_de_la_table; -- Vider une table

-- Copier/coller le code : employes.sql 

DESC employes; -- Observer la structure de la table ainsi que les champs (desc pour describe, c'est la description)

--#################### Requete de selection (affichage)
----------------------------------------------

-- Affichage complet
SELECT id_employes, prenom, nom, sexe, service, date_embauche, salaire FROM employes; -- Je souhaite conna�tre toutes les informations des employ�s travaillant dans l�entreprise ?
SELECT * FROM employes ; -- Affichage de la table employes avec la racourci de l'�toile "*" pour dire "ALL".
-- Affiche-moi [* toutes les colonnes] de [nom de la table]

----------------------------------------------

-- Quels sont les noms et pr�noms des employ�s travaillant dans l�entreprise ?
SELECT nom, prenom FROM employes ;

----------------------------------------------

-- Quels sont les diff�rents services occup�s par les employ�s travaillant dans l�entreprise ? * A donner en exercice * !
SELECT service FROM employes; 

----------------------------------------------

-- DISTINCT
-- Affichage des services (diff�rents)
SELECT DISTINCT service FROM employes;-- Quels sont les diff�rents services occup�s par les employ�s travaillant dans l�entreprise ? * A donner en exemple * !
-- DISTINCT permet d'�liminer les doublons

----------------------------------------------

-- Condition WHERE
-- Affichage des employ�s du service informatique
SELECT nom, prenom, service FROM employes WHERE service='informatique'; -- Je souhaite conna�tre le nom et pr�nom de tous les employ�s de l�entreprise travaillant dans le service informatique ?
-- * D�ssiner le [SCHEMA4_decompositionrequete] *
-- WHERE = � condition que
-- WHERE [colonne = valeur]

----------------------------------------------

-- BETWEEN
-- Affichage des employ�s ayant �t� recrut�s entre 2010 et aujourd'hui
SELECT nom, prenom, date_embauche FROM employes WHERE date_embauche BETWEEN '2010-01-01' AND '2016-01-11' ;

SELECT CURDATE();

SELECT nom, prenom, date_embauche FROM employes WHERE date_embauche BETWEEN '2010-01-01' AND CURDATE() ;

-- Pas de diff�rence entre les quotes ' et les guillemets ". Quand il y a une valeur il faut mettre les guillemets " ou les quotes ', en revanche quand il s'agit d'un chiffre, on ne doit pas les mettre.
-- BETWEEN + AND = entre ... et ...
-- Curdate : On s'en sert pour ne pas proposer en reservation des billets de tgv/avion, chambre d'hotel dans une date ant�rieur (ex billet de tgv en date d'hier).

----------------------------------------------

-- LIKE : valeur approchante
-- Affichage des employ�s ayant un pr�nom commen�ant par la lettre s

SELECT prenom FROM employes WHERE prenom LIKE 's%';	 -- Je souhaite conna�tre le pr�nom des personnes commen�ant par la lettre � s � dans l�entreprise?
SELECT prenom FROM employes WHERE prenom LIKE '%s';  -- Je souhaite conna�tre le pr�nom des personnes de l�entreprise qui contient un trait d�union dans leur pr�nom ? -----> LIKE est tr�s utile dans la recherche d'appartement par Code Postal. 75 et non pas 75015.
SELECT prenom FROM employes WHERE prenom LIKE '%-%';

-- % : peut importe la suite...

-- ID -- nom 	-- code_postal
-- 1     Appart1	  75015
-- 2     Appart2	  75001
-- 3     Appart3	  75017----

-- SELECT * FROM appartement WHERE code_postal = 75 ;
-- SELECT * FROM appartement WHERE code_postal LIKE '75%' ;

-- * D�ssiner le [SCHEMA5_Like] *

----------------------------------------------

-- Affichage de tous les employ�s (sauf les informaticiens) -- Je souhaite conna�tre le nom et pr�nom de tous les employ�s de l�entreprise NE travaillant PAS dans le service informatique ?
SELECT nom, prenom, service FROM employes WHERE service != 'informatique' ;
-- != diff�rent de ... 

----------------------------------------------

-- Affichage de tous les employ�s gagnant un salaire sup�rieur a 3000 �
-- * Pour l'intervenant: �crire au tableau les OPERATEURS DE COMPARAISONS. il sont dans le support de cours SQL (page 26) *
SELECT nom, prenom, service, salaire FROM employes WHERE salaire>3000; -- Je souhaite conna�tre le nom et pr�nom, des employ�s de l�entreprise ayant un salaire sup�rieur � 3000� ? le signe � n'est pas enregistr� dans la BDD puisqu'il s'agit d'un champ de type INT.
-- * REd�ssiner le [schema4_decompositionrequete] pour cette requete *

----------------------------------------------

-- ORDER BY
-- Affichage des employ�s dans l'ordre alphab�tique
SELECT prenom FROM employes ORDER BY prenom ASC ;
SELECT prenom FROM employes ORDER BY prenom DESC ;
SELECT prenom, salaire FROM employes ORDER BY salaire DESC, prenom ASC;
-- ORDER BY permet d'effectuer un classement.
-- ASC : Ascendant croissant
-- DESC : Descendant d�croissant

----------------------------------------------

-- LIMIT
-- Affichage des employ�s 3 par 3
SELECT prenom FROM employes ORDER BY prenom ASC LIMIT 0,3 ;
SELECT prenom FROM employes ORDER BY prenom ASC LIMIT 3,3 ;
SELECT prenom FROM employes ORDER BY prenom ASC LIMIT 6,3 ;
 -- Je souhaite conna�tre le nom et pr�nom de l�employ� de l�entreprise ayant le salaire le plus �lev� (nous ne le connaissons pas). LIMIT est utilis� sur un site pour la pagination, soit la s�paration en plusieurs pages d'une liste de donn�es.
-- 
----------------------------------------------

-- Affichage des employ�s avec un salaire annuel
SELECT prenom, salaire*12 FROM employes ;
SELECT prenom, salaire*12 AS 'salaire annuel' FROM employes ;
-- AS : Alias

----------------------------------------------

-- SUM
-- Affichage de la "masse salarial" sur 12 mois
SELECT SUM(salaire*12) FROM employes ;
-- SUM : Somme
-- Je souhaite conna�tre la masse salariale de l�entreprise (sur une ann�e) ?
-- Je souhaite conna�tre le nom, le pr�nom et le salaire annuel de tous les employ�s dans l�entreprise ? M�me si ce n'est pas vraiment comme ca qu'on le calcul mais cela permet de donner une id�e.

----------------------------------------------

-- AVG
-- Affichage du salaire moyen.
SELECT AVG(salaire) FROM employes ;
-- AVG : moyenne.
-- ROUND
SELECT ROUND(AVG(salaire)) FROM employes ;
-- ROUND permet d'arrondir.

----------------------------------------------

-- COUNT
-- Affichage du nombre de femme(s) dans l'entreprise
SELECT COUNT(*) FROM employes WHERE sexe = 'f';
-- COUNT permet de compter

----------------------------------------------

-- MIN
-- Affichage du salaire minimum/maximum
SELECT MIN(salaire) FROM employes ;
SELECT MAX(salaire) FROM employes ;
 -- Je souhaite savoir quel est le salaire le plus bas que j�attribue dans l�entreprise (sur un mois) ?

SELECT prenom, MIN(salaire) FROM employes ;
-- /!\ r�sultat incoh�rent. ce n'est pas Jean-Pierre qui gagne 1390 � mais c'est Julien Cottet.

-- Qui gagne le salaire minimum ?
SELECT prenom FROM employes WHERE salaire = (SELECT MIN(salaire) FROM employes);

SELECT prenom, MIN(salaire) FROM employes; -- (*** Mauvais exemple ***) * A donner en exercice * : Je souhaite savoir quel est le salaire le plus bas que j�attribue dans l�entreprise (sur un mois) ? Pas d'erreur car la syntaxe est bonne cependant le r�sultat est �ronn�, Min r�alise son travail mais la requ�te retourne la premi�re ligne de la table, hors ce n'est pas daniel qui gagne le salaire le plus faible.
SELECT prenom,salaire FROM employes WHERE salaire = (SELECT MIN(salaire) FROM employes); -- Je souhaite savoir quel est le salaire le plus bas que j�attribue dans l�entreprise ainsi que le pr�nom de l�employ� concern� ? * A donner en exemple * ! Req. Imbriqu� sur la m�me table

----------------------------------------------

-- IN
SELECT prenom,service FROM employes WHERE service IN ('comptabilite', 'informatique'); -- Je souhaite conna�tre le pr�nom des employ�s travaillant dans le service comptabilit� et le service informatique ? In lorsqu'il y a plusieurs valeurs � annoncer.
-- Affichage des employ�s travaillant dans le service comptabilit� et le service informatique.
SELECT nom, prenom, service FROM employes WHERE service IN('comptabilite' ,'informatique');
-- IN permet d'inclure plusieurs valeurs
-- = permet d'inclure 1 seule valeur

----------------------------------------------

-- NOT IN
SELECT prenom,service FROM employes WHERE service NOT IN ('comptabilite', 'informatique'); -- A l�inverse, pour conna�tre le pr�nom des employ�s ne faisant pas partie des services comptabilit� et informatique
-- Affichage des employ�s ne travaillant pas dans le service comptabilit� et le service informatique.
SELECT nom, prenom, service FROM employes WHERE service NOT IN('comptabilite' ,'informatique');
SELECT prenom,service FROM employes WHERE service NOT IN ('comptabilite', 'informatique') ORDER BY service ASC; -- A l�inverse, pour conna�tre le pr�nom des employ�s ne faisant pas partie des services comptabilit� et informatique, class� par service.
-- NOT IN permet d'exclure plusieurs valeurs.
-- != permet d'exclure 1 seule valeur.

----------------------------------------------

-- Affichage des commerciaux gagnant un salaire inf�rieur ou �gal a 2000 �
SELECT nom, prenom, salaire, service FROM employes WHERE service = 'commercial' AND salaire <= 2000 ;
SELECT prenom, nom, salaire, service FROM employes WHERE service='commercial' AND salaire <= 2000 ; -- Je souhaite conna�tre le pr�nom et nom des employ�s travaillant dans le service commercial avec un salaire inf�rieur ou avoisinant les 1500� ?
-- AND : et... (condition compl�mentaire)

----------------------------------------------

SELECT prenom, nom, service, salaire FROM employes WHERE service='production' AND salaire= 1900 OR salaire=2300 ; -- Je souhaite conna�tre le pr�nom et nom des employ�s du service commercial travaillant pour un salaire de 1500 ou 1800 � ? Sans les parenth�ses le OR prend le dessus sur le AND.
SELECT prenom, nom, service, salaire FROM employes WHERE service='production' AND (salaire= 1900 OR salaire=2300) ; -- Je souhaite conna�tre le pr�nom et nom des employ�s du service commercial travaillant pour un salaire de 1500 ou 1800 � ? ordre de priorit� gr�ce au parenth�se.

----------------------------------------------

-- GROUP BY
-- Affichage du nombre d'employ�(s) par service
SELECT service, COUNT(*) AS nombre FROM employes GROUP BY service; -- Permet d'afficher le nombre d'employ�(s) par service. GROUP BY va r�-associer les nombres (+1) par service.

SELECT service, COUNT(*) AS nombre FROM employes GROUP BY service HAVING COUNT(*) > 2;  -- Permet d'afficher les services o� il y a plus d'un employ�. HAVING remplace WHERE avec GROUP BY.
-- GROUP BY permet d'effectuer des regroupements.
-- Cas particulier : on utilise HAVING dans le cas d'un GROUP BY pour appliquer une condition.

----------------------------------------------

-- Requete d'Insertion
INSERT INTO employes VALUES (NULL, 'prenom', 'nom', 'm', 'informatique', '2015-01-11', 1000);
--	INSERT INTO employes VALUES ('', 'prenom', 'nom', 'm', 'informatique', '2015-01-11', 1000);
INSERT INTO employes (prenom, nom, sexe, service, date_embauche, salaire) VALUES ('prenom', 'nom', 'm', 'informatique', '2015-01-11', 1000);

SELECT * FROM employes; -- On observe le contenu de la table avant l'insertion !
-- > exercice: chacun s'ins�re dans les employes
INSERT INTO employes (id_employes, prenom, nom, sexe, service, date_embauche, salaire) VALUES (809, 'alexis', 'richy', 'm', 'informatique', '2011-12-28', 1800); -- Insertion d'un employ�

INSERT INTO employes VALUES (8059, 'alexis', 'richy', 'm', 'informatique', '2012-01-28', 1800); -- Insertion d'un employ� sans pr�ciser la liste des champs si le nombre de valeur attendues est respect�e.
SELECT * FROM employes; -- On observe le contenu de la table apr�s l'insertion !

----------------------------------------------

-- Requ�te de modification
SELECT * FROM employes ;
UPDATE employes SET salaire = 1391 WHERE id_employes = 699 ;
UPDATE employes SET salaire = 1392, service ='informatique' WHERE id_employes = 699 ;
SELECT * FROM employes ;

SELECT * FROM employes; -- On observe le contenu de la table avant les modifications !

INSERT INTO employes (id_employes, prenom, nom, sexe, service, date_embauche, salaire) VALUES (8059, 'test', 'test', 'm', 'marketing', '2010-07-05', 2600); -- insertion
REPLACE INTO employes (id_employes, prenom, nom, sexe, service, date_embauche, salaire) VALUES (NULL, 'test2', 'test2', 'm', 'marketing', '2010-07-05', 2601); -- remplacement (si l'id est trouv�, replace se comporte comme insert, sinon il se comporte comme update).
REPLACE INTO employes (id_employes, prenom, nom, sexe, service, date_embauche, salaire) VALUES (8059, 'test2', 'test2', 'm', 'marketing', '2010-07-05', 2601); -- remplacement (si l'id est trouv�, replace se comporte comme insert, sinon il se comporte comme update).

SELECT * FROM employes; -- On observe le contenu de la table apres les modifications !

----------------------------------------------

-- Requ�te de suppression
SELECT * FROM employes ;
DELETE FROM employes WHERE id_employes = 388 ;
SELECT * FROM employes; -- On observe le contenu de la table avant les suppressions !

DELETE FROM employes WHERE nom='lagarde'; -- suppression de l'employ� ayant le nom "chevel". nous sommes dans un exemple de cours donc �a va mais ceci serait plus prudent par son id !

DELETE FROM employes WHERE service = 'informatique' AND id_employes != 7802 ; -- supprimer tout les informaticiens sauf 1

DELETE FROM employes WHERE id_employes=7388 OR id_employes = 7900 ; -- supprimer 2 employ�s qui n'ont pas de point commun. Il s'agit d'un OR et non pas d'un AND car 2 employ�s ne peuvent pas poss�der 2 id diff�rent en m�me temps.
		
DELETE FROM employes; -- revient � faire un truncate pour vider.


SELECT * FROM employes; -- On observe le contenu de la table apres les suppressions !

----------------------------------------------

--#################### Requete de selection avec group by (Copier/coller localite.sql)

-- SELECT id_secteur, ville, chiffre_affaires FROM localite; -- affichage : Aucune secteur ne fait plus de 600 000� de chiffre d'affaire (mais la ville de Paris qui apparait 2 fois � un chiffre d'affaire sup�rieur � 600 000 si on le calcul).

-- SELECT id_secteur, ville, SUM(chiffre_affaires) FROM localite GROUP BY ville; -- affichage en associant toutes les valeurs (group by) qui ont la m�me ville : Paris ressort bien avec un chiffre d'affaire sup�rieur � 600 000.

-- SELECT id_secteur, ville, SUM(chiffre_affaires) FROM localite GROUP BY ville HAVING SUM(chiffre_affaires)>600000; -- HAVING remplace WHERE avec GROUP BY.

--> exercice: Ins�r� une nouvelle ville dans la table localite
--> exercice: Modifier votre nom et pr�nom (mettre des maj) dans la m�me requete et affili� vous cette ville
--> exercice: Supprimer votre ville dans la table localite
-------------------------------------------------------------------------------------------------------------------------------------
-- Questions : (* � donner en exercice et �crire la correction au tableau *)
-- quel est le prenom de l'employ� 627 ?
-- quel est le salaire de m�lanie ?
-- combien de personne gagne 2000 � de salaire ?
-- Afficher les employ�s du service commercial.
-- Afficher les employ�s ayant �t� recrut�s en 2010.
-- Afficher l'employ� gagnant le salaire le plus �lev� (prenom + salaire)


-- 1 -- Afficher la profession de l'employ� 547.
	SELECT service FROM employes WHERE id_employes=547;
		
-- 2 -- Afficher la date d'embauche d'Amandine.
	SELECT date_embauche FROM employes WHERE prenom='Amandine';
		
-- 3 -- Afficher le nom de famille de Guillaume
	SELECT nom FROM employes WHERE prenom = 'Guillaume';
		
-- 4 -- Afficher le nombre de personne ayant un n� id_employes commen�ant par le chiffre 5.
	SELECT COUNT(*) FROM employes WHERE id_employes LIKE '5%';
		
-- 5 -- Afficher le nombre de commerciaux.
	SELECT COUNT(*) as 'nombre' FROM employes WHERE service='commercial';
		
-- 6 -- Afficher le salaire moyen des informaticiens (+arrondie).
	SELECT round(AVG( salaire )) FROM employes WHERE service = 'informatique';
		
-- 7 -- Afficher les 5 premiers employ�s apr�s avoir classer leur nom de famille par ordre alphab�tique.
	SELECT * FROM employes ORDER BY nom ASC LIMIT 0,5 ;
		
-- 8 -- Afficher le co�t des commerciaux sur 1 ann�e.
	SELECT SUM(salaire*12) FROM employes WHERE service='commercial';
		
-- 9 -- Afficher le salaire moyen par service. (service + salaire moyen)
	SELECT service, round(AVG( salaire )) FROM employes GROUP BY service;
		
-- 10 -- Afficher le nombre de recrutement sur l'ann�e 2010 (+alias).
	10-1-> SELECT COUNT(*) as 'nb de recrutement' FROM employes WHERE date_embauche BETWEEN '2010-01-01' AND '2010-12-31';
	10-2-> SELECT COUNT(*) as 'nb de recrutement' FROM employes WHERE date_embauche LIKE '2010%';
	10-3-> SELECT COUNT(*) as 'nb de recrutement' FROM employes WHERE date_embauche >= '2010-01-01' AND date_embauche <= '2010-12-31';
		
-- 11 -- Afficher le salaire moyen appliqu� lors des recrutements sur la p�riode allant de 2005 a 2007
	SELECT AVG(salaire) FROM employes WHERE date_embauche BETWEEN '2005-01-01' AND '2007-12-31'

-- 12 -- Afficher le nombre de service diff�rent
	SELECT COUNT(DISTINCT(service)) FROM employes ;

-- 13 -- Afficher tous les employ�s (sauf ceux du service production et secr�tariat)
	SELECT nom, prenom FROM employes WHERE service NOT IN('production', 'secretariat');

-- 14 -- Afficher conjoitement le nombre d'homme et de femme dans l'entreprise
	SELECT sexe, COUNT(*) FROM employes GROUP BY sexe ;

-- 15 -- Afficher les commerciaux ayant �t� recrut�s avant 2005 de sexe masculin et gagnant un salaire sup�rieur a 2500 �
	SELECT nom, prenom FROM employes WHERE service = 'commercial' AND sexe = 'm' AND date_embauche < '2005-01-01' AND salaire > 2500 ;

-- 16 -- Qui a �t� embauch� en dernier
	SELECT * FROM employes ORDER BY date_embauche DESC LIMIT 0,1 ;
	SELECT * FROM employes WHERE date_embauche = (SELECT MAX(date_embauche) FROM employes);

-- 17 -- Afficher les informations sur l'employ� du service commercial gagnant le salaire le plus �lev�
	SELECT * FROM employes WHERE service = 'commercial' AND salaire = (SELECT MAX(salaire) FROM employes WHERE service = 'commercial');

-- 18 -- Afficher le pr�nom du comptable gagnant le meilleur salaire
	SELECT prenom FROM employes WHERE service = 'comptabilite' AND salaire = (SELECT MAX(salaire) FROM employes WHERE service = 'comptabilite');

-- 19 -- Afficher le pr�nom de l'informaticien ayant �t� recrut� en premier
	SELECT * FROM employes WHERE service = 'informatique' AND date_embauche = (SELECT MIN(date_embauche) FROM employes WHERE service = 'informatique');

-- 20 -- Augmenter chaque employ� de 100 �
	UPDATE employes SET salaire = salaire+100;

-- 21 -- Supprimer les employ�s du service secr�tariat
	DELETE FROM employes WHERE service = 'secretariat';
		
		
------------------------------------------------------------------------------------------------------------------------------------
-- Jointure (INNER JOIN) /
-- JOINTURE INTERNE
--SELECT e.prenom, e.nom, l.ville
--FROM employes e
--INNER JOIN localite l
--ON e.id_secteur = l.id_secteur ;

--SELECT e.prenom, e.nom, l.ville
--FROM employes e, localite l
--WHERE e.id_secteur = l.id_secteur ;

-- JOINTURE EXTERNE (SANS CORRESPONDANCE EXIGE)
--SELECT e.prenom, e.nom, l.ville
--FROM employes e LEFT JOIN localite l
--ON e.id_secteur = l.id_secteur ;
------------------------------------------------------------------------------------------------------------------------------------
-- Divers/
-- Donner le salaire et le nom des employ�s gagnant plus que tous les commerciaux:	SELECT prenom, salaire, service FROM employes WHERE salaire >  (SELECT max(salaire) FROM employes WHERE service='commercial');	

SELECT prenom, salaire FROM employes WHERE salaire > ANY (SELECT salaire FROM employes2 WHERE service='info'); -- (cela pourrait �tre l'�quivalent du IN pour le =)
-- Permet de sortir les prenoms des employes avec au moins 1 charge de communication dans leur service: SELECT E1.prenom FROM employes E1, EMPloyes E2 WHERE E1.id_secteur = E2.id_secteur AND E2.service = 'charge de communication';
-- Afficher tout les employ�s arriv� dans l'entreprise avant l'ann�e 2000: -> SELECT * FROM employes WHERE date_embauche < 2000;


-- Combien y'a t'il de commerciaux gagnant un salaire inf�rieur ou avoisinant les 1500� : -> SELECT COUNT( prenom ) FROM employes WHERE service = 'commercial' AND salaire <= 1500;


-- Afficher le pr�nom des commerciaux du secteur 10 ou 20 : -> SELECT prenom FROM employes WHERE secteur=10 or secteur=20; (XOR uniquement l'un ou l'autre)
-- Afficher toutes les femmes, commercial travaillant sur le secteur 10 : -> SELECT prenom FROM employes WHERE sexe='f' AND secteur=10;
-- Donner les prenoms des personnes commen�ant par E : -> SELECT prenom FROM employes WHERE prenom LIKE 'E%';
-- Afficher les prenoms et noms des employes ne travaillant pas en compta et en informatique de sexe masculin : -> SELECT prenom, nom FROM employes WHERE service NOT IN ('comptabilite', 'informatique') AND sexe IN('m');
-- Connaitre le salaire le plus petit des secretaires en renommant la colonne 'salaire minimum' : -> SELECT min(salaire) FROM employes WHERE service='secretariat';