-- tester un champs NULL
-- Affichage des ID des livres qui n'ont pas été rendu
SELECT id_livre FROM emprunt WHERE date_rendu IS NULL;
-- Un champs NULL se teste toujours avec IS

-- REQUETE IMBRIQUEE
------------------------------------------------------------------
-- Titre des livres dans la nature 
SELECT titre FROM livre WHERE id_livre IN
    (SELECT id_livre FROM emprunt WHERE date_rendu IS NULL);

-- requete détaillée : 
SELECT titre FROM livre WHERE id_livre IN(100,105);

-- Afin de réaliser une requète imbriquée (ou jointure) il faut obligatoirement un champ commun entre les 2 tables

------------------------------------------------------------------
-- Liste des abonnés n'ayant pas rendu les livres à la bibliothèque
SELECT prenom FROM abonne WHERE id_abonne IN
    (SELECT id_abonne FROM emprunt WHERE  date_rendu IS NULL);
 
-- requete détaillée : 
SELECT prenom FROM abonne WHERE id_abonne IN(3,2);

------------------------------------------------------------------
-- Exo : Nous aimerions connaitre le numéro (id_livre) des livre(s) que Chloé a emprunté à la bibliothèque ?

SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'; -- affiche 3
SELECT id_livre FROM emprunt WHERE id_abonne = 3; -- affiche 100 et 105

SELECT id_livre FROM emprunt WHERE id_abonne = 
    (SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'); -- affiche 100 et 105

-------------------------------------------------------------------
-- Exo : afficher les prénoms des abonnés ayant emprunté un livre le 19/12/2014
SELECT id_abonne FROM emprunt WHERE date_sortie = '2014-12-19'; 
SELECT prenom FROM abonne WHERE id_abonne IN(3,4,1);

SELECT prenom FROM abonne WHERE id_abonne IN
    (SELECT id_abonne FROM emprunt WHERE date_sortie = '2014-12-19');

-------------------------------------------------------------------
-- Exo : Combien de livres Guillaume a emprunté à la bibliothèque ?
SELECT COUNT(*) AS 'nb emprunt' FROM emprunt WHERE id_abonne = 
    (SELECT id_abonne FROM abonne WHERE prenom = 'Guillaume');

-------------------------------------------------------------------
-- Exo : Afficher la liste des abonnés ayant déja emprunté un livre d'ALPHONSE DAUDET
SELECT id_livre FROM livre WHERE auteur = 'ALPHONSE DAUDET'; -- affiche 103
SELECT id_abonne FROM emprunt WHERE id_livre = 103; -- affiche 4
SELECT prenom FROM abonne WHERE id_abonne = 4; -- Affiche Laura

SELECT prenom FROM abonne WHERE id_abonne IN
    (SELECT id_abonne FROM emprunt WHERE id_livre IN 
        (SELECT id_livre FROM livre WHERE auteur = 'ALPHONSE DAUDET'));

------------------------------------------------------------------
-- Exo : Nous aimerions connaitre le titre des livres que Chloé a emprunté à la bibliothèque
SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'; -- affiche 3
SELECT id_livre FROM emprunt WHERE id_abonne = 3; -- affiche 100 et 105
SELECT titre FROM livre WHERE id_livre IN(100,105);

SELECT titre FROM livre WHERE id_livre IN
    (SELECT id_livre FROM emprunt WHERE id_abonne = 
        (SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'));

------------------------------------------------------------------
-- Exo : nous aimerions connaitre le titre des livres que Chloe n a pas encore emprunté 
SELECT titre FROM livre WHERE id_livre NOT IN
    (SELECT id_livre FROM emprunt WHERE id_abonne = 
        (SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'));

------------------------------------------------------------------
-- Exo : nous aimerions connaitre le titre des livres que Chloe n a pas encore rendu
SELECT titre FROM livre WHERE id_livre IN 
    (SELECT id_livre FROM emprunt WHERE date_rendu IS NULL AND id_abonne = (
        SELECT id_abonne FROM abonne WHERE prenom = 'Chloe'));

SELECT titre FROM livre WHERE id_livre IN 
    (SELECT id_livre FROM emprunt WHERE id_abonne = (
        SELECT id_abonne FROM abonne WHERE prenom = 'Chloe') AND date_rendu IS NULL);
------------------------------------------------------------------
-- Exo : Qui a emprunté le plus de livre ? 
SELECT id_abonne FROM emprunt GROUP BY id_abonne ORDER BY COUNT(*) DESC LIMIT 0,1 -- affiche 2
SELECT prenom FROM abonne WHERE id_abonne = 2; 

SELECT prenom FROM abonne WHERE id_abonne =
    (SELECT id_abonne FROM emprunt GROUP BY id_abonne ORDER BY COUNT(*) DESC LIMIT 0,1);

--------------------------------------------------------------------------------
-- JOINTURE 
-- Nous aimerions connaitre les date sortie et date rendu pour l'abonné Guillaume (quand est-il passé à la bibliothèque)

-- JOINTURE
-- 'a.prenom' correspond au champs prenom de la table 'abonne' portant le prefixe 'a'
SELECT a.prenom, e.date_sortie, e.date_rendu  
FROM emprunt e, abonne a 
WHERE a.id_abonne = e.id_abonne
AND a.prenom = 'Guillaume';
-- 1er ligne : ce que je souhaite afficher
-- 2éme ligne : de quelle table cela provient, et de qu'elle table je vais avoir besoin ?
-- 3ème ligne : condition, quel est le champ commun dans les 2 tables qui me permet d'effectuer la jointure
-- 4ème ligne : condition complémentaire

-- IMBRIQUEE
SELECT date_sortie, date_rendu FROM emprunt WHERE id_abonne = 
    (SELECT id_abonne FROM abonne WHERE prenom = 'Guillaume');

-- un jointure et un requete imbriquée permettent de faire des relations entre les différentes  tables afin d'avoir des colonnes associé pour ne former qu'un seul résultat
-- une jointure est possible dans tout les cas 
-- une requete imbriqué est possible seulement dans le cas où le résultat est issu de la même table
-- les requetes imbriqué aura quand même l'avantage de s'executer plus rapidement

--------------------------------------------------------------------------
-- Exo : Nous aimerions connaitre les mouvements des livres (date_sortie, date_rendu) écrit par ALPHONSE DAUDET 

-- JOINTURE
SELECT l.auteur, l.titre, e.date_sortie, e.date_rendu
FROM livre l, emprunt e
WHERE e.id_livre = l.id_livre
AND l.auteur = 'ALPHONSE DAUDET';

-- IMBRIQUEE
SELECT date_sortie, date_rendu FROM emprunt WHERE id_livre IN
    (SELECT id_livre FROM livre WHERE auteur = 'ALPHONSE DAUDET');

----------------------------------------------------------------------------
-- Exo : Qui emprunté le livre "Une vie" sur l'anné 2014

-- JOINTURE
SELECT a.prenom, l.titre, e.date_sortie
FROM abonne a, livre l, emprunt e
WHERE a.id_abonne = e.id_abonne
AND e.id_livre = l.id_livre
AND l.titre = 'Une vie'
AND e.date_sortie LIKE '2014%'; 

-- IMBRIQUEE 
SELECT prenom FROM abonne WHERE id_abonne IN
    (SELECT id_abonne FROM emprunt WHERE id_livre IN(
        SELECT id_livre FROM livre WHERE titre = 'Une vie') AND date_sortie LIKE '2014%');

SELECT prenom FROM abonne WHERE id_abonne IN
    (SELECT id_abonne FROM emprunt WHERE date_sortie LIKE '2014%' AND id_livre IN(
        SELECT id_livre FROM livre WHERE titre = 'Une vie'));

---------------------------------------------------------------------------------
-- Exo : nous aimerions connaitre le nombre de livre(s) emprunté(s) par chaque abonné

-- JOINTURE
SELECT a.prenom, COUNT(e.id_abonne) AS 'nb livre emprunte'
FROM abonne a, emprunt e
WHERE a.id_abonne = e.id_abonne
GROUP BY e.id_abonne;

-- IMBRIQUEE
SELECT id_abonne, COUNT(id_livre) AS 'nb livre emprunte' FROM emprunt GROUP BY id_abonne; 

--------------------------------------------------------------------------------
-- Exo : Nous aimerions connaitre le nombre de livre(s) a rendre pour chaque abonne 

-- JOINTURE
SELECT a.prenom, COUNT(e.id_livre) AS 'nb de livre a rendre'
FROM abonne a, emprunt e
WHERE a.id_abonne = e.id_abonne
AND e.date_rendu IS NULL
GROUP BY e.id_abonne;







  



























